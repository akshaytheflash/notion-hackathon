import { useCallback, useEffect, useState } from "react";
import { api, type Workflow, type Approval, type IntegrationsStatus } from "./lib/api";
import { useLiveEvents } from "./lib/useLiveEvents";
import { IntegrationStrip } from "./components/IntegrationStrip";
import { WorkflowList } from "./components/WorkflowList";
import { EventLog } from "./components/EventLog";
import { ApprovalsPanel } from "./components/ApprovalsPanel";

export default function App() {
  const [workflows, setWorkflows] = useState<Workflow[]>([]);
  const [approvals, setApprovals] = useState<Approval[]>([]);
  const [integrations, setIntegrations] = useState<IntegrationsStatus | null>(null);
  const [running, setRunning] = useState(false);
  const [demoError, setDemoError] = useState<string | null>(null);
  const { events, connected } = useLiveEvents();

  const refresh = useCallback(async () => {
    try {
      const [wf, ap, st] = await Promise.all([
        api.listWorkflows(),
        api.listApprovals(),
        api.integrationsStatus(),
      ]);
      setWorkflows(wf);
      setApprovals(ap);
      setIntegrations(st);
    } catch (e) {
      // Backend may not be running yet -- fail quietly, the UI still renders.
      console.error(e);
    }
  }, []);

  useEffect(() => {
    refresh();
    const id = setInterval(refresh, 4000);
    return () => clearInterval(id);
  }, [refresh]);

  // Refresh immediately whenever a new state transition event comes in over
  // the socket, so the workflow list doesn't wait for the next poll tick.
  useEffect(() => {
    if (events.length > 0) refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [events.length]);

  async function runDemo() {
    setRunning(true);
    setDemoError(null);
    try {
      await api.runPrimaryScenario();
      await refresh();
    } catch (e) {
      setDemoError(e instanceof Error ? e.message : "Demo run failed");
    } finally {
      setRunning(false);
    }
  }

  return (
    <div className="min-h-screen flex flex-col">
      <header
        className="flex items-center justify-between px-6 py-4 border-b"
        style={{ borderColor: "var(--color-hairline)" }}
      >
        <div>
          <p className="text-[11px] font-mono tracking-widest uppercase" style={{ color: "var(--color-signal-cyan)" }}>
            Enterprise AI OS
          </p>
          <h1 className="text-lg font-semibold">Incident Command Center</h1>
        </div>
        <div className="flex items-center gap-6">
          <IntegrationStrip status={integrations} />
          <button
            onClick={runDemo}
            disabled={running}
            className="rounded-md px-4 py-2 text-sm font-semibold transition-colors disabled:opacity-50"
            style={{
              backgroundColor: "var(--color-signal-amber)",
              color: "var(--color-ink)",
            }}
          >
            {running ? "Running…" : "Run P0 Incident Demo"}
          </button>
        </div>
      </header>

      {demoError && (
        <div
          className="mx-6 mt-4 rounded-md px-4 py-2 text-xs font-mono"
          style={{ backgroundColor: "rgba(239, 83, 80, 0.1)", color: "var(--color-signal-red)" }}
        >
          {demoError}
        </div>
      )}

      <main className="flex-1 grid grid-cols-12 gap-4 p-6 min-h-0">
        <section
          className="col-span-7 rounded-lg border min-h-0 flex flex-col"
          style={{ backgroundColor: "var(--color-panel)", borderColor: "var(--color-hairline)" }}
        >
          <WorkflowList workflows={workflows} />
        </section>

        <section
          className="col-span-5 rounded-lg border min-h-0 flex flex-col"
          style={{ backgroundColor: "var(--color-panel)", borderColor: "var(--color-hairline)" }}
        >
          <ApprovalsPanel approvals={approvals} />
        </section>

        <section
          className="col-span-12 rounded-lg border min-h-[280px] max-h-[360px] flex flex-col"
          style={{ backgroundColor: "var(--color-panel)", borderColor: "var(--color-hairline)" }}
        >
          <EventLog events={events} connected={connected} />
        </section>
      </main>
    </div>
  );
}
